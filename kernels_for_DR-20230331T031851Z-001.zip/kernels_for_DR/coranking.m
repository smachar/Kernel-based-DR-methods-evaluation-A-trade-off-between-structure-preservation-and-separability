function c = coranking(hdpd,ldpd)
% Function 
%
% c = coranking(hdpd,ldpd)
%
% computes the coranking matrix starting from the matrices of pairwise
% distances hdpd and ldpd (in the high- and low-dimensional spaces, 
% respectively). Be careful, the output is made of uint32 integers.
%
% References:
% [1] John A. Lee, Michel Verleysen.
%     Rank-based quality assessment of nonlinear dimensionality reduction.
%     Proc. 16th ESANN, Bruges, pp 49-54, April 2008.
% [2] John A. Lee, Michel Verleysen.
%     Quality assessment of nonlinear dimensionality reduction: 
%     rank-based  criteria.
%     Neurocomputing, 72(7-9):1431-1443, March 2009.
%
% Copyright J. A. Lee, October 28, 2012.

if ~isdist(hdpd,0) 
    error('Invalid distance matrix in hdpd.');
end    
if ~isdist(ldpd,0)
    error('Invalid distance matrix in ldpd.');
end

% check size equality
tmp1 = size(hdpd);
tmp2 = size(ldpd);
if any(tmp1~=tmp2)
    error('The matrices hdpd and ldpd do not have the same sizes.');
end
nbr = tmp1(1); % full size (N)
sss = tmp1(2); % subset size
if nbr<sss
    disp('Warning in coranking: transposing upper blocks into left blocks.')
    c = coranking(hdpd',ldpd');
    return
end

% compute sorting permutations
[~,ndx1] = sort(hdpd,1);
[~,ndx2] = sort(ldpd,1);

% % compute the corresponding ranks
% % (in order to be vectorized, sort operations are required)
% % [jnk,ndx3] = sort(ndx1);
% [jnk,ndx4] = sort(ndx2);

% compute the corresponding ranks
% (modern versions of matlab run simple loops very fast)
% (this avoids sorting and reduces the memory cost)
% ndx3 = zeros(nbr,nbr,'uint32');
ndx4 = zeros(nbr,sss,'uint32');
for j = 1:sss
    for i = 1:nbr
        % ndx3(ndx1(i,j),j) = i; % not really necessary, see next loop
        ndx4(ndx2(i,j),j) = i;
    end 
end
% clear ndx1;
clear ndx2;

% initialize the coranking matrix to zero
c = zeros(nbr,nbr,'uint32');

% compute the coranking matrix (successive increments)
for j = 1:sss
    for i = 1:nbr
        % % strictly according the coranking definition 
        % % (this requires knowing the ranks in both spaces)
        % k = ndx3(i,j);
        % l = ndx4(i,j);
        % c(k,l) = c(k,l) + 1;

        % more efficient 
        % (this requires knowing the ranks in one space only)
        h = ndx4(ndx1(i,j),j); % i replaces the rank given by ndx3
        c(i,h) = c(i,h) + 1;
    end
end

% remove useless first row and column
c = c(2:end,2:end);
