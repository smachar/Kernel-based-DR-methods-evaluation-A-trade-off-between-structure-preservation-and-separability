function [n,x,p,b,h] = nx_diagrams(k,varargin)
% The function
%
% [n,x,p,b,h] = nx_diagrams(k,c1,c2,...,cM)
%
% calls M times the function nx_trusion in order to compute the intrusion
% and extrusion rates for each coranking matrix c1, c2, ..., cM. With the
% results, a intrusion/extrusion diagram is drawn for values of K between
% 1 and k. If k<=1, then k is interpreted as a fraction of N-2, where N is
% the total number of points (and N-1 is the size of all coranking
% matrices). Along with the results of nx_trusion, the function also
% outputs a handle for the curves.
%
% References:
% [1] John A. Lee, Michel Verleysen.
%     Quality assessment of nonlinear dimensionality reduction: rank-based
%     criteria.
%     Neurocomputing, 72(7-9):1431-1443, March 2009.
%

% return if nothing to do
if length(varargin)<1,
    % initialise outputs
    n = [];
    x = [];
    p = [];
    b = [];
    return
end

% get the number of coranking matrices
rpt = floor(length(varargin)/2);
if 2*rpt~=length(varargin), error('Incorrect number of arguments'); end

% get their size
nbr = size(varargin{1},1);

% default value for k
if isempty(k), k = nbr; end
k = min(nbr,abs(k));

% initialise outputs
n = zeros(nbr,rpt);
x = zeros(nbr,rpt);
p = zeros(nbr,rpt);
b = zeros(nbr,rpt);

% initialize the figure;
figure; hold on;

% for each coranking matrix
mkr = cell(rpt,1);
lbl = cell(rpt,1);
for m = 1:rpt
    % extract data from varargin
    cm = varargin{2*m-1}; % m-th coranking matrix
    mkr{m} = varargin{2*m}(1); % m-th marker
    if length(varargin{2*m})>1, lbl{m} = ['  ',varargin{2*m}(2:end)]; end % m-th label

    % check the size
    if size(cm,1)~=nbr, error('The coranking matrices have different sizes'); end
    if size(cm,1)~=size(cm,2), error(['The ',num2str(m),'-th coranking matrix is not square']); end

    % compute the rates
    [nm,xm,pm,bm] = nx_trusion(cm);

    % concatenate with previous results
    n(:,m) = nm;
    x(:,m) = xm;
    p(:,m) = pm;
    b(:,m) = bm;
end

% criteria
Q_NX = n + x + p;
B_NX = x - n;
LCMC = Q_NX - b;
avg_Q_NX = sum(Q_NX) ./ nbr
avg_B_NX = sum(B_NX) ./ nbr
[~,idx] = max(LCMC);
K_max = idx(1,:);
% L = (nbr-K_max) ./ (nbr-1) % between 0 and 1
L = (nbr+1-K_max) ./ nbr % between 1/nbr and 1

lav_Q_NX = zeros(1,rpt);
rav_Q_NX = zeros(1,rpt);
lav_LCMC = zeros(1,rpt);
rav_LCMC = zeros(1,rpt);
for m = 1:rpt
    lav_Q_NX(m) = sum(Q_NX(1:idx(m),m)) ./ idx(m);
    rav_Q_NX(m) = sum(Q_NX(idx(m):nbr,m)) ./ (nbr+1-idx(m));
    lav_LCMC(m) = 2*nbr*sum(LCMC(1:idx(m),m)) ./ idx(m) ./ (nbr+nbr+1-idx(m));
    rav_LCMC(m) = 2*nbr*sum(LCMC(idx(m):nbr,m)) ./ (nbr+1-idx(m)) ./ (nbr+1-idx(m));
end
max_Q_NX = diag(Q_NX(idx,:))';
Q_loc = L .* max_Q_NX;
lav_Q_NX
rav_Q_NX

% draw curves
if k>1.0
    v1 = 1:nbr;
else
    v1 = 0.0:(1/(nbr-1)):1.0;
end
h = plot(v1,Q_NX,'-'); % Q_NX
set(h,'LineWidth',1);
g = plot(v1,B_NX,'--'); % B_NX
set(g,'LineWidth',1);
f = plot([0,v1(end)],[0,0],'k:'); % baseline for B_NX
set(f,'LineWidth',1);
f = plot([0,v1(end)],[0,1],'k:'); % baseline for Q_NX
set(f,'LineWidth',1);

% draw small markers for Q_NX, B_NX
v2 = floor(k/20):floor(k/10):k;
v3 = v1(v2);
h = plot(v3,Q_NX(v2,:),'.');
g = plot(v3,B_NX(v2,:),'.');
for m = 1:rpt
    set(h(m),'Marker',mkr{m},'LineWidth',1);
    set(g(m),'Marker',mkr{m},'LineWidth',1);
end

% draw large markers for L, maxQ_NX
h = plot([v1(idx);v1(idx)],[max_Q_NX;max_Q_NX]);
for m = 1:rpt
    set(h(m),'Marker',mkr{m},'LineWidth',2);
end

% finalise the figure;
hold off;
axis([0,k,max(-1,0.1*floor(10*min(min(x(1:k,:)-n(1:k,:))))),min(1,0.1*ceil(10*max(max(n(1:k,:)+x(1:k,:)+p(1:k,:)))))]);
if k>1.0, xlabel('{\itK}'); else xlabel('({\itK}-1)/({\itN}-2)'); end
ylabel('{\itB}_{NX}({\itK}) (dashed) &  {\itQ}_{NX}({\itK}) (solid)');
% title('Intrusion/extrusion diagram');
legend(h,lbl,'Location','East');

% display scores
figure;
hold on;
set(plot([(nbr+1)/2/nbr;1],[1/nbr;(nbr+1)/2/nbr],'k:'),'LineWidth',1);
i = plot([rav_Q_NX;rav_Q_NX],[lav_Q_NX;lav_Q_NX],'.');
legend(i,lbl,'Location','SouthEast');
%text(rav_Q_NX,lav_Q_NX,lbl);
y = (1+K_max)./(2*nbr);
x = (K_max+nbr)./(2*nbr);
j = plot([x;x],[y;y],'.');
axis([0.5,1.0,0.0,1.0]);
text(0.6,0.05,'Good <- Localness -> Bad');
xlabel('Bad <- {\itQ}_{global} -> Good');
ylabel('Bad <- {\itQ}_{local} -> Good');
for m = 1:rpt
    set(i(m),'Marker',mkr{m},'LineWidth',2);
    set(j(m),'Marker',mkr{m},'LineWidth',2);
end
hold off;

% % display scores
% figure;
% subplot(1,2,1);
% i = plot([rav_Q_NX',rav_Q_NX']',[lav_Q_NX',lav_Q_NX']','.');
% text(rav_Q_NX,lav_Q_NX,lbl);
% axis([0.0,0.5,0.0,1.0]);
% %xlabel('Bad <- {\itQ}_{tauc} -> Good');
% %ylabel('Bad <- {\itQ}_{pauc} -> Good');
% subplot(1,2,2);
% j = plot([rav_LCMC',rav_LCMC']',[lav_LCMC',lav_LCMC']','.');
% text(rav_LCMC,lav_LCMC,lbl);
% axis([0,1,0,1]);
% %xlabel('Extrusive <- {\itB}_{tauc} -> Intrusive');
% %ylabel('Bad <- {\itQ}_{pauc} -> Good');
% for m = 1:rpt
%     set(i(m),'Marker',mkr{m},'LineWidth',2);
%     set(j(m),'Marker',mkr{m},'LineWidth',2);
% end
