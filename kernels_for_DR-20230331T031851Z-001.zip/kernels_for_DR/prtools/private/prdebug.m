function prdebug(s)

disp('  ')
disp(s)
disp('   ')