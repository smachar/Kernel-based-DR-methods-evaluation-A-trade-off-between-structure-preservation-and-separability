%MSE Dataset overload of Matlab's MSE

function e = mse(a)

e = mse(+a);