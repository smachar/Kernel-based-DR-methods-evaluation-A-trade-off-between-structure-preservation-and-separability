%GETOUT_CONV Get out_conv field in mapping
%
%    OUT_CONV = GETOUT_CONV(W)

% $Id: getout_conv.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function out_conv = getout_conv(w)
			out_conv = w.out_conv;
return
