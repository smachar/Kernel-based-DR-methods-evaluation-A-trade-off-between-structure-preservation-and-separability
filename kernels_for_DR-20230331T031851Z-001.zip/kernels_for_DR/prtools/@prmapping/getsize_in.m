%GETSIZE_IN Get size_in field of mapping
%
%    SIZE_IN = GETSIZE_IN(W)

% $Id: getsize_in.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function size_in = getsize_in(w)

		
size_in = w.size_in;
return
