%GETSCALE Get scale field of mapping
%
%    SCALE = GETSCALE(W)

% $Id: getscale.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function scale = getscale(w)
			scale = w.scale;
return
