%UMINUS Mapping overload

function c = uminus(a)

c = setscale(a,-getscale(a));