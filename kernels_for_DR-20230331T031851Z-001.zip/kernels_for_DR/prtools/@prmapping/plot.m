%PLOT Mapping overload (generates error)

% $Id: plot.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function plot(varargin)

	error('Use for displaying classifiers and mappings PLOTC, PLOTM or SHOW')

return

