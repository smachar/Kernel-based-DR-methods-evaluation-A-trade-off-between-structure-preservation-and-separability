%GETDATASET Get dataset of datafile

function d = getdataset(a)
	
		
	d = a.prdataset;

return
