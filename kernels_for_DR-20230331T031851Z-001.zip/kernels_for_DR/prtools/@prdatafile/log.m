%LOG Datafile overload

function c = log(a)
	
		
	c = a*filtm([],'log');

return
