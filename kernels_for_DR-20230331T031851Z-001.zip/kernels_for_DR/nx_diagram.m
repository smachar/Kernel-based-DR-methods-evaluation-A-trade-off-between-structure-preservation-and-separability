function [n,x,p,b,h] = nx_diagram(k,varargin)
% The function
% 
% [n,x,p,b,h] = nx_diagram(k,c1,c2,...,cM)
% 
% calls M times the function nx_trusion in order to compute the intrusion
% and extrusion rates for each coranking matrix c1, c2, ..., cM. With the
% results, a intrusion/extrusion diagram is drawn for values of K between 
% 1 and k. If k<=1, then k is interpreted as a fraction of N-2, where N is 
% the total number of points (and N-1 is the size of all coranking 
% matrices). Along with the results of nx_trusion, the function also 
% outputs a handle for the curves.
%
% References:
% [1] John A. Lee, Michel Verleysen.
%     Quality assessment of nonlinear dimensionality reduction: rank-based 
%     criteria.
%     Neurocomputing, 72(7-9):1431-1443, March 2009.
%

% return if nothing to do
if length(varargin)<1,
    % initialise outputs
    n = [];
    x = [];
    p = [];
    b = [];
    return
end

% get the number of coranking matrices
rpt = length(varargin);

% get their size
nbr = size(varargin{1},1);

% default value for k
if isempty(k), k = nbr; end
k = min(nbr,abs(k));

% initialise outputs
n = zeros(nbr,rpt);
x = zeros(nbr,rpt);
p = zeros(nbr,rpt);
b = zeros(nbr,rpt);

% initialize the figure;
figure; hold on;

% for each coranking matrix
for m = 1:rpt
    % extract the m-th coranking matrix
    cm = varargin{m};
    
    % check the size
    if size(cm,1)~=nbr, error('The coranking matrices have different sizes'); end
    if size(cm,1)~=size(cm,2), error(['The ',num2str(m),'-th coranking matrix is not square']); end
    
    % compute the rates
    [nm,xm,pm,bm] = nx_trusion(cm);
    
    % concatenate with previous results
    n(:,m) = nm;
    x(:,m) = xm;
    p(:,m) = pm;
    b(:,m) = bm;
end

% draw
if k>1.0
    v1 = 1:nbr;
else
    v1 = 0.0:(1/(nbr-1)):1.0;
end
h = plot(v1,n+x+p,'-'); % Q_NX
set(h,'Linewidth',2);
g = plot(v1,x-n,'--'); % B_NX
set(g,'Linewidth',2);
f = plot([0,v1(end)],[0,0],'k--'); % baseline for B_NX
set(f,'Linewidth',1);
f = plot([0,v1(end)],[0,1],'k-'); % baseline for Q_NX
set(f,'Linewidth',1);

% finalise the figure;
hold off;
axis([0,k,max(-1,0.1*floor(10*min(min(x(1:k,:)-n(1:k,:))))),min(1,0.1*ceil(10*max(max(n(1:k,:)+x(1:k,:)+p(1:k,:)))))]);
if k>1.0, set(xlabel('$K$'),'Interpreter','LaTeX'); else set(xlabel('({\itK}-1)/({\itN}-2)'),'Interpreter','LaTeX'); end
set(ylabel('$B_\mathrm{NX}$  \&  $Q_\mathrm{NX}$'),'Interpreter','LaTeX');
title('Intrusion/extrusion diagram');

% scores
qauc = mean(n+x+p)
bauc = mean(x-n)
qaucw = sum(bsxfun(@times,n+x+p-b,(nbr:-1:1)'.*(4/nbr/(nbr+1))))
baucw = sum(bsxfun(@times,x-n,(nbr:-1:1)'.*(2/nbr/(nbr+1))))
[~,idx] = max(n+x+p-b);
val = n+x+p;
val = diag(val(idx,:))';
ql = val .* (nbr-idx(1,:)) ./ (nbr-1)
