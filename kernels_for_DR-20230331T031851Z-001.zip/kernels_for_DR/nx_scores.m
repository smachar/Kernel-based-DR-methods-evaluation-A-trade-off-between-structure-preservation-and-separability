function [Qavg,Bavg,Ravg] = nx_scores(k,pts,X,varargin)
% Function
%
% nx_scores(k,pts,X,Y1,M1,L1,Y2,M2,L2,...,YT,MT,LT)
% nx_scores(k,pts,DX,DY1,M1,L1,DY2,M2,L2,...,DYT,MT,LT)
% nx_scores(k,pts,X,Y_M_L_cells)
% nx_scores(k,pts,DX,DY_M_L_cells)
%
% calls T times the functions pairwisedistances, coranking, and nx_trusion 
% in order to compute the Euclidean distances, the coranking matrices, and
% the intrusion and extrusion (NX) rates for each embedding Y1, Y2, ..., YM
% of  data set X. Strings M1 to MT contain each a pair of valid color and 
% marker characters (e.g. bgrcmykw followed by sdhp^v<>.ox*+). 
% Strings L1 to LT contain the legend or name of the embeddings.
% If X, Y1, ..., YT are square matrices, they are considered as distances.
% Arguments Yt, Mt, and Lt can also be passed in a cell matrix {Yt;Mt;Lt}.
% With the NX rates, the Q_NX and B_NX curves are computed.
% From the Q_NX criterion, the random baseline is subtracted to obtain
% the local continuity meta-criterion (LCMC), which is then normalized
% by the range between perfect (1) and random (K/N-1) to get R_NX.
% The R_NX criterion is the relative improvement w.r.t. a random embedding.
%
% The various curves (Q_NX, R_NX, etc.) can be displayed in diagrams
% w.r.t. neighborhood size K.
% Parameter k specifies the range for the abscissae, from 1 to k.
% Any k>1 means a linear scale for the abscissae between 1 and k.
% The cases isempty(k) and k==1 are equivalent to specifying k=nbr.
% Any k<=0 means a logarithmic scale for the abscissae, from 1 to N.
% If numel(k)>1, then k(2) is used to draw a vertical line in the diagram.
% Parameter pts is a string that specifies the demanded diagrams.
% Any character in the following list generates a new figure:
% q: Q_NX(K) only
% b: Q_NX(K) and B_NX(K) in a single plot
% l: LCMC(K)
% r: R_NX(K) only
% p: R_NX(K) and percentiles of R_NX(K)
%    The percentiles of each R_NX curve are displayed as vertical bars in
%    a second diagram. The horizontal position of the bars is given by
%    the weighted average (sum_K K*R_NX(K)) / (sum_K R_NX(K)) .
%
% References:
% [1] John A. Lee, Michel Verleysen.
%     Quality assessment of nonlinear dimensionality reduction: 
%     rank-based criteria.
%     Neurocomputing, 72(7-9):1431-1443, March 2009.
% [2] J. A. Lee, E. Renard, G. Bernard, P. Dupont, M. Verleysen
%     Type 1 and 2 mixtures of Kullback-Leibler divergences
%     as cost functions in dimensionality reduction
%     based on similarity preservation
%     Accepted in Neurocomputing, 2013.
%
% Copyright J.A.Lee, January 6, 2013.

% number of data
nbr = size(X,1);
nmo = nbr - 1; % number minus one
nmt = nbr - 2; % number minus two

% get the number of embeddings
if length(varargin)==1 && iscell(varargin{1}), varargin = varargin{1}; end
rpt = floor(numel(varargin)/3);
if 3*rpt~=numel(varargin), error('Incorrect number of arguments'); end

% default value for k
if isempty(k), k = nbr; end
if numel(k)>2, lgnd = k(3); else lgnd = []; end
if numel(k)>1, kopt = k(2); else kopt = []; end
k = k(1);
if k<=0
    k = nbr; % full range
    loab = true; % logarithmic scale for abscissae
else
    loab = false; % linear scale for abscissae
end
k = abs(k);
if k<1, k = k*nbr; end
k = min(nbr,abs(k));

% Euclidean distances for the data set
if isdist(X)
    DX = X;
else
    DX = pairwisedistances(X);
end

% initialise outputs
n = zeros(nmo,rpt);
x = zeros(nmo,rpt);
p = zeros(nmo,rpt);
b = zeros(nmo,rpt);

% colormap
cmp = colorcube(12);

% colors, markers, and labels
clr = zeros(rpt,3);
mkr = cell(rpt,1);
lbl = cell(rpt,1);

% for each embedding
for t = 1:rpt
    % extract embedding from varargin
    Yt = varargin{3*t-2}; % t-th embedding
    if size(Yt,1)~=nbr, error(['The ',num2str(t),'-th embedding has not the right size']); end
    if isdist(Yt)
        DYt = Yt;
    else
        
            DYt = pairwisedistances(Yt);
        if ~isdist(DYt)
            DYt = dist(Yt');
        end
        
    end
    
    % extract color from varargin
    c = varargin{3*t-1}(1);
    if isnan(str2double(c))
        switch c
            case 'r', clr(t,:) = [1,0,0];
            case 'g', clr(t,:) = [0,1,0];
            case 'b', clr(t,:) = [0,0,1];
            case 'k', clr(t,:) = [0,0,0];
            case 'w', clr(t,:) = [1,1,1];
            case 'c', clr(t,:) = [0,1,1];
            case 'm', clr(t,:) = [1,0,1];
            case 'y', clr(t,:) = [1,1,0];
            case 'R', clr(t,:) = [1,0,0]/2;
            case 'G', clr(t,:) = [0,1,0]/2;
            case 'B', clr(t,:) = [0,0,1]/2;
            case 'K', clr(t,:) = [0,0,0]/2;
            case 'W', clr(t,:) = [1,1,1]/2;
            case 'C', clr(t,:) = [0,1,1]/2;
            case 'M', clr(t,:) = [1,0,1]/2;
            case 'Y', clr(t,:) = [1,1,0]/2;
            otherwise
                error('Wrong color character!');
        end
    else
        clr(t,:) = cmp(str2double(c)+2,:);
    end
    
    % extract marker and label from varargin
    mkr{t} = varargin{3*t-1}(2); % t-th color and marker
    lbl{t} = varargin{3*t};      % t-th label + blank space

    % compute the rates
    
    [nt,xt,pt,bt] = nx_trusion(coranking(DX,DYt));

    % concatenate with previous results
    n(:,t) = nt;
    x(:,t) = xt;
    p(:,t) = pt;
    b(:,t) = bt;
end

% quality curves
Q_NX = n + x + p;
B_NX = x - n;
LCMC = Q_NX - b;
R_NX = LCMC(1:end-1,:) ./ (1-b(1:end-1,:)); % avoid division by zero for k==nmo

% percentiles of R_NX
Kavg = ((1:nmt) * R_NX) ./ sum(R_NX,1);
 pct = [5,10,25,50,75,90,95,100];
Rpct = prctile(R_NX,pct');

% scalar quality criteria
wgh = 1./(1:nmo);
wgh = wgh/sum(wgh);
Qavg = wgh*Q_NX; % area under Q_NX in a logplot
Bavg = wgh*B_NX; % area under B_NX in a logplot
wgh = 1./(1:nmt);
wgh = wgh/sum(wgh);
Ravg = wgh*R_NX; % area under R_NX in a logplot

% "twice ranks" (across neighbors and then across methods)
[~,TR] = sort(R_NX,2); % avoid last row of Q_NX and LCMC
[~,TR] = sort(  TR,2); % ranks from last to first for all K
AR = wgh*(rpt+1-TR); % weighted average in a logplot
FS = wgh*5/max(1,rpt-1)*(TR-1); % five stars system (from 0 to 5)

for t = 1:rpt
    disp([lbl{t},': av.rank= ',sprintf('\t%2.1f',AR(t)),' ',sprintf('\t%1.2f',FS(t)),' stars']);
end

for c = 1:length(pts)
    cc = lower(pts(c));
    
    % initialise the figure;
   % figure;
    
    if cc=='p'
        % raise axes
        subplot(2,1,1);
    end
    
    % K range, Y label, Y coordinates, Y bounds, legend position
    switch cc
        case 'l'
            kra = nmo;
            yla = 'LCMC$(K)$';
            yco = LCMC;
            ylb = 0;
            yub = 100;
            lpo = 'NorthEast';
        case 'q'
            kra = nmo;
            yla = '$100 Q_{\mathrm{NX}}(K)$';
            yco = Q_NX;
            ylb = 0;
            yub = 100;
            lpo = 'SouthEast';
        case 'b'
            kra = nmo;
            yla = '$100 B_{\mathrm{NX}}(K)$, $100 Q_{\mathrm{NX}}(K)$';
            yco = Q_NX;
            ylb = 5*floor(20*min(B_NX(:)));
            yub = 5* ceil(20*max( yco(:)));
            lpo = 'East';
        case {'r','p'}
            kra = nmt;
            yla = '$100 R_{\mathrm{NX}}(K)$';
            yco = R_NX;
            ylb = 0;
            yub = 5* ceil(20*max( yco(:)));
            lpo = 'South'; % not always optimal when loab is true
            if ~isempty(lgnd)
                if lgnd<0, lpo = 'SouthWest'; elseif lgnd>0, lpo = 'SouthEast'; end
            end
        otherwise
            disp('Incorrect plot type character, skipping...');
    end
    
    % prepare axes
    set(gca,'FontName','Times','FontSize',10);
    hold on;
    
    % draw optional vertical line
    if ~isempty(kopt)
        h = plot([kopt,kopt],[0,100],'k-');
        %set(h,'LineWidth',0.5);
    end
    
    % draw baselines
    v1 = 1:kra;
    if cc=='l'
        % LCMC
        h = plot(v1,100/v1(end)*v1(end:-1:1),'k-');
        set(h,'LineWidth',1);
    elseif cc=='q' || cc=='b'
        % Q_NX
        h = plot(v1,100/v1(end)*v1,'k-');
        set(h,'LineWidth',1);
    end
    if cc=='b'
        h = plot(v1,zeros(size(v1)),'k-');
        set(h,'LineWidth',1);
    end
    
    % draw isolevels
    stp = 0.1;
    for lvl = stp:stp:1-stp
        if cc=='l'
            % LCMC
            h = plot(v1,100*lvl/v1(end)*v1(end:-1:1),'k:');
            set(h,'LineWidth',1);
            
            % Q_NX in LCMC diagram
            h = plot(v1,100*(lvl-v1/v1(end)),'k:');
            set(h,'LineWidth',1);
        else
            % Q_NX or R_NX (horizontal)
            h = plot(v1,100*lvl*ones(size(v1)),'k:');
            set(h,'LineWidth',1);
            
            if cc=='q'
                % LCMC in Q_NX diagram
                h = plot(v1,100*(lvl+(1-lvl)/v1(end)*v1),'k:');
                set(h,'LineWidth',1);
            elseif cc=='r' || cc=='p'
                % Q_NX in R_NX diagram
                h = plot(v1,100*(1-(1-lvl)*nmo./(nmo-v1)),'k:');
                set(h,'LineWidth',1);
            end
        end        
    end

    % draw curves
    for t = 1:rpt
        if cc=='b'
            h = plot(v1,100*B_NX(:,t),'--');
            set(h,'Color',clr(t,:),'LineWidth',1.5);
        end
        h = plot(v1,100*yco(:,t),'-');
        set(h,'Color',clr(t,:),'LineWidth',1.5);
    end
    
    % draw small markers
    if loab
        v2 = 2.^(1:floor(log2(kra)));
    else
        v2 = floor(nmt/20):floor(kra/10):nmt;
    end
    v3 = v1(v2);
    for t = 1:rpt
        if cc=='b'
            h(t) = plot(v3,100*B_NX(v2,t),mkr{t});
            set(h(t),'Color',clr(t,:),'LineWidth',2);
        end
        h(t) = plot(v3,100*yco(v2,t),mkr{t});
        set(h(t),'Color',clr(t,:),'LineWidth',2);
    end

    % legend
    lgd = cell(rpt,1);
    for t = 1:rpt
        tmp = [lbl{t},' $\,\,$'];
        if cc=='l'
            lgd{t} = tmp;
        elseif cc=='q' || cc=='b'
            lgd{t} = [sprintf(' $% 2.1f$ ',abs(100*Qavg(t))),tmp];
        else
            lgd{t} = [sprintf(' $% 2.1f$ ',abs(100*Ravg(t))),tmp];
            %if Bavg(t)>0,
            %    lgd{t} = [sprintf(' $+% 2.1f$ ',abs(100*Bavg(t))),lbl{t},' $\,\,$'];
            %else
            %    lgd{t} = [sprintf(' $-% 2.1f$ ',abs(100*Bavg(t))),lbl{t},' $\,\,$'];
            %end
        end
    end
    set(legend(h,lgd,'Location',lpo),'Interpreter','LaTeX');

    % finalise the figure
    hold off;
    axis([0,k,ylb,yub]);
    if loab
        set(gca,'Xscale','log');
    end
    xlabel('$K$','Interpreter','LaTeX','FontName','Times','FontSize',20);
    ylabel( yla ,'Interpreter','LaTeX','FontName','Times','FontSize',20);

    if cc=='p'
        % raise and prepare axes
        subplot(2,1,2);
        set(gca,'FontName','Times','FontSize',10);
        hold on;
        
        % draw R_NX isolevels
        for lvl = stp:stp:1-stp
            h = plot(v1,100*lvl*ones(size(v1)),'k:');
            set(h,'LineWidth',1);
        end
        
        % draw bars and "whiskers" (markers)
        for t = 1:rpt
            set(plot(Kavg(t)*ones(8,1),100*Rpct( :     ,t),[mkr{t}    ]),'Color',clr(t,:),'LineWidth',2);
            set(plot(Kavg(t)*ones(5,1),100*Rpct(2:end-2,t),[mkr{t},'-']),'Color',clr(t,:),'LineWidth',2);
            set(text(Kavg(t),100*Rpct(end,t),['$\;$ ',lbl{t}]),'Rotation',45,'HorizontalAlignment','left','VerticalAlignment','bottom','FontSize',10,'Interpreter','LaTeX');
        end
        
        % finalise the figure 
        
        xlabel( '$K^{\mathrm{avg}}$' ,'Interpreter','LaTeX');
        ylabel(['\%=[ ',sprintf('%i ',pct(1)),sprintf('%i--',pct(2:end-3)),sprintf('%i ',pct(end-2:end)),'] of $100 R_{\mathrm{NX}}(K)$'],'Interpreter','LaTeX');
        axis([max(0,10*floor(min(Kavg)/10)),min(nbr,10*ceil(max(Kavg)/10)),5*floor(20*min(Rpct(:))),5*ceil(20*max(Rpct(:)))]);
    end
end

hold off
%
% figure;
% 
% subplot(2,2,1);
% hold on;
% for t = 1:rpt
%     set(plot(Qavg(t),Bavg(t),mkr{t}),'Color',clr(t,:),'LineWidth',2);
% end
% xlabel('Qavg');
% ylabel('Bavg');
% 
% subplot(2,2,2);
% hold on;
% for t = 1:rpt
%     set(plot(Qavg(t),Ravg(t),mkr{t}),'Color',clr(t,:),'LineWidth',2);
% end
% xlabel('Qavg');
% ylabel('Ravg');
% 
% subplot(2,2,3);
% hold on;
% for t = 1:rpt
%     set(plot(Qavg(t),FS(t),mkr{t}),'Color',clr(t,:),'LineWidth',2);
% end
% xlabel('Qavg');
% ylabel('FS');
% grid on;
% 
% subplot(2,2,4);
% hold on;
% for t = 1:rpt
%     set(plot(Ravg(t),FS(t),mkr{t}),'Color',clr(t,:),'LineWidth',2);
% end
% xlabel('Ravg');
% ylabel('FS');
% grid on;
% 
% 
% 
