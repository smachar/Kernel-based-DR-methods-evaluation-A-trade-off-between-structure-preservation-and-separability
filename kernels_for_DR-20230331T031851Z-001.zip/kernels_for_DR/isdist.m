function b = isdist(D,lft)
% Function
%
% b = isdist(D,lft)
%
% checks that D is a valid (left block of a) distance matrix.
%
% Input: 
%   D  : D is the matrix to be tested
%   lft: if lsb is specified and true, isdist also considers left
%        sub-blocks as being valid
% Output: 
%   b  : Boolean flag indicating whether D is a valid distance matrix
%
% Copyright J. A. Lee, October 28, 2012.

if nargin<2, lft = 0; end

% size
[nbr,sss] = size(D);

% depending on form factor...
if nbr<sss
    % D has more columns than rows
    if ~lft
        b = false;
    else
        disp('Warning in isdist: transposing upper block into left block.');
        S = D(1:nbr,1:nbr);
        b = all(diag(S)<eps) && all(all(abs(S-S')<eps)) && all(D(:)>=0);
    end
elseif nbr>sss
    % D has more rows than columns
    if ~lft
        b = false;
    else
        S = D(1:sss,1:sss);
        b = all(diag(S)<eps) && all(all(abs(S-S')<eps)) && all(D(:)>=0);
    end
else
    % D is square
    b = all(diag(D)<eps) && all(all(abs(D-D')<eps)) && all(D(:)>=0);
end


