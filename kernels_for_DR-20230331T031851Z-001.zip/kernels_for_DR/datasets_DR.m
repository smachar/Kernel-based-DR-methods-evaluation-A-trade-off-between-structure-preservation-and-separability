function [X,L,db] = datasets_DR(did,opG,norm_opt)

% Syntaxis [X,L] = datasets_DR(did)
% did is to be selected as:
%'a' Rollo Suizo 
%'b' Esfera 
%'c' Toroide
%'d' Helix
%'e' Mnist
%'f' Faces
%'g' Coil
%'h' Manuales

switch did 
     case 'a' % swissroll
        db = 'Swiss Roll';
        
        N = 1000;
     
        s = RandStream('mcg16807','Seed',29); RandStream.setGlobalStream(s);
        % load swiss roll dataset with 3000 points

        t = (3*pi*(rand(N,1).^0.65)+pi/2);
        height = 100*rand(N,1);
        X = [t.*cos(t) height  t.*sin(t)];
        L = t;

      case 'b' % Sphere
        db = 'Spherical Shell';
        
        spd = 3; % Sphere dimension
        nbr = 1000; % numero de puntos

        X = randn(nbr,3);
        X = bsxfun(@rdivide, X, sqrt(sum(X.^2,2)));
        if spd>3
            X = [X,0.5*randn(nbr,spd-3)./sqrt(spd-3)];
        end
        L = 32+64/180*atan2(X(:,1),X(:,2));
        K = ceil(nbr/3);
        
      case 'c' % Toroide
        db = 'Toroidal';
        nbr = 1000; % numero de puntos
        nl = 15; % number of loops
        U = (0:nbr-1)';
        L = rem(U,nbr/nl);
        U = 2*pi/nbr*U;
        X = [(2+cos(nl*U)).*cos(U),(2+cos(nl*U)).*sin(U),sin(nl*U)];
        K = round(nbr/nl);
        
    case 'd' % Datos helix generados por drtools
        db = 'helix';
        
        [X, labels] = generate_data('helix', 2000);
        L = labels;
        
    case 'e' % MNIST
            db = 'MNIST';
            nbr = 1000;
            load 'mnist_train_1.mat'
            sel = randperm(60000);
            sel = sel(1:nbr);
            %sel = 1:60:60000;
            X = train_X(sel,:);
            L = train_labels(sel);
            K = ceil(nbr/10);
            
     case 'f' % Frey faces
           db = 'FreyF';
           load frey_rawface.mat
           stp = 1;%2;
           X = double(ff(:,1:stp:end)');
           L = 1:size(X,1);

    case 'g' % Coil20
           db = 'Coil 20';
           s = RandStream('mcg16807','Seed',29); RandStream.setGlobalStream(s);
           load 'coil_1440.mat'
           L = reshape(bsxfun(@plus, (1:20), zeros(72,1)), [1440,1]);
           stp = 1;%2;
           X = X(1:stp:end,:);
           L = L(1:stp:end);
           
    case 'h' % Datos manuales
           db = 'manuales';
           X=[1,2,3;5,6,7;9,1,3;7,9,2;5,5,6;3,7,9];
           %Diagrama de dispersion
           L = (1:6); 

    otherwise
        error('Unknown data set');
end
if norm_opt
    X        = X./repmat(max(abs(X)),size(X,1),1);
end
% Opci�n para graficar o no los scatter de los datos
if opG 
    figure(1);
    box on; daspect([1 1 1]);
    set(gca,'Fontname','Times','Fontsize',26);
    title(db,'FontSize', 30);
    axis on

    if strcmp(db ,'MNIST') % solo para la bd MNIST

     colmap = jet(64); colmap = colmap(5:6:64,:);
     nr = 10;
     nc = 10;
     Xs = X(1:100,:);
     for i = 1:10
         tmp = X(L==i,:);
         Xs(nc*(i-1)+(1:nc),:) = tmp(1:nc,:);
     end
        [r,c] = meshgrid(1:nr,1:nc);
        mosaic1([c(:),r(:)],Xs(1:(nr*nc),:),28,28,nc,nr,true);
        scatter((nc+0.5)*ones(nr,1),(1.5:(nr-2)/(nr-1):nr-0.5)',450,colmap,'o','filled')
        axis([0,nc+1,0,nr]);
        colormap(flipdim(gray,1));
        axis equal;

    elseif strcmp(db ,'faces')   % solo para la bd faces
        colmap = jet(64); colmap = colmap(4:4:64,:);
        nr = 16;
        nc = 16;
        [r,c] = meshgrid(1:nr,1:nc);
        mosaic1([c(:),r(:)],X(1:floor(end/(nr*nc)):end,:),20,28,nc,nr,true);
        scatter((nc+0.5)*ones(nr,1),(1.5:(nr-2)/(nr-1):nr-0.5)',150,colmap,'o','filled')
        axis([0,nc+1,0,nr]);
        colormap(gray);
        axis equal;

     elseif strcmp(db ,'Coil 20')   % solo para la bd coil   
        colmap = jet(20);
        nr = 20;
        nc = 9;
        [r,c] = meshgrid(1:nr,1:nc);
        mosaic1([c(:),r(:)],X(1:8/stp:1440/stp,:),128,128,9,20);
        scatter((nc+0.5)*ones(nr,1),(1.5:(nr-2)/(nr-1):nr-0.5)',150,colmap,'o','filled')
        axis([0,nc+1,0,nr]);
        axis equal;
        colormap gray;  

    else % para las demas bd
        scatter3(X(:,1),X(:,2),X(:,3),30,L,'o','filled');
    end

end


