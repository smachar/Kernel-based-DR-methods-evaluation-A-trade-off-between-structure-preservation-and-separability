function Y = kernel_PCA(K,d)

[V,Lambda]   = eig(K);
[Lambda,ind] = sort(diag(Lambda),'descend');
Y            = V(:,ind(1:d));
    