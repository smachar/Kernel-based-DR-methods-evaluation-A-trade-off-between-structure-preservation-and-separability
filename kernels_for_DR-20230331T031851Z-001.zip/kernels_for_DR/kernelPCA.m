function Y = kernelPCA(X,K,d)
    [V,D]  = eig(K);
    [D,P]  = sort(diag(D),'descend');
    Y      = V(:,P(1:d));
end
