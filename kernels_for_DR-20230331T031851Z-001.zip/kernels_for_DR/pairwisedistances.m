function [d,p,r,g,a] = pairwisedistances(x,gbr,gbp)
% Function
%
% [d,p,r,g,a] = pairwisedistances(x,gbr,gbp)
%
% computes the pairwise distances from the coordinates in x 
% (one row per observation).
% If gbr is equal to 'k', an undirected graph is build based on K-ary 
% neighborhoods, where K is specified by ceil(gbp). As the graph is 
% undirected, there might actually be more than K neighbors.
% If gbr is equal to 'e', the graph construction relies on epsilon-balls
% centered on each point.
% Distances are computed according to the shortest (weighted) path in the
% resulting geometric graph.
% Any other value of gbr, or if it is left unspecified, leads to the
% computation of Euclidean distance (without graph).
% With the gbr and gbp options it is also possible to specify previously
% computed distances instead of coordinates in x. Matrix x must then be
% square with zero diagonal elements.
% Matrix d contains the pairwise distances.
% Columns of matrix p gives the paths.
% Matrix r corresponds to the ranks (number of edges in the paths).
% Integer g is the index of of the graph gravity center.
% Matrix a is the adjacency matrix.
% 
% Copyright J.A.Lee, December 31, 2012.

% check arguments
if nargin<2, gbr = 'a'; end
if nargin<3, gbp = []; end

% check argument values
if isempty(gbr), gbr = 'a'; end
gbr = lower(gbr(1));
if isempty(gbp)
    if gbr=='k', gbp = 6; elseif gbr=='e', gbp = 0.1; end 
end

% size and dimension of data set
nbr = size(x,1);

% vectors of ones
n1 = ones(nbr,1);

% compute inner products and corresponding symmetrized Euclidean distances
if size(x,1)==size(x,2) && all(diag(x)==0)
    d = x; % 0.5*(x+x'); % is symmetry mandatory?
else
    g = x*x';
    d = bsxfun(@minus,diag(g),g);
    d = sqrt(d + d');
end

% build a graph and compute the shortest paths
if ~isempty(gbr) && (gbr=='k' || gbr=='e')
    % adjacency matrix and rank matrix
    a = zeros(nbr,nbr,'uint32');
    r = uint32(nbr+1)*(ones(nbr,nbr,'uint32') - eye(nbr,'uint32'));

    % build graph edges
    if gbr == 'k'
        [~,idx] = sort(d);
        for j = 1:nbr
            tmp = idx(2:(1+gbp),j);
            a(tmp,j) = 1;
            r(tmp,j) = 1;
            d(idx((2+gbp):end,j),j) = inf;
        end
    elseif gbr == 'e'
        % gbp = gbp * mD; % makes everything proportional
        for j = 1:nbr
            for i = 1:nbr
                if d(i,j)>gbp
                    d(i,j) = inf;
                elseif i~=j
                    a(i,j) = 1;
                    r(i,j) = 1;
                end
            end
        end
    end

    % convert into an undirected graph
    d = min(d,d');
    r = min(r,r');
    a = max(a,a');

    if nargout==1
        % Floyd algorithm to compute (only) the length of all shortest paths
        for j = 1:nbr
            dj = d(:,j);
            d = min(d,bsxfun(@plus,dj,dj'));
        end
    else
        % Floyd algorithm to compute all shortest paths (paths, lengths, ranks)

        % path matrix
        ni = uint32(1:nbr);
        p = a .* ni(n1,:);

        % Floyd iterations (for each vertex)
        for j = 1:nbr
            % length of the combined paths from j to k through i
            dj = d(:,j);
            tmd = bsxfun(@plus,dj,dj');

            % rank of the combined paths from j to k through i
            rj = r(:,j);
            tmu = bsxfun(@plus,rj,rj');

            % logical indices (combined shorter than initial paths)
            lidx = tmd<d;

            % update lengths and ranks (logical indexing)
            d(lidx) = tmd(lidx);
            r(lidx) = tmu(lidx);

            % update paths
            pj = p(:,j);
            tmu = pj(:,n1);
            p(lidx) = tmu(lidx);
        end
    end
    
    % mention that there are more than one connected component
    if any(any(d==inf))>0
        disp('More than one connected component!');
        g = [];
    else
        % compute mass center (computed from distances)
        [~,idx] = sort(sum(d.^2));
        g = idx(1);
    end
else
    p = [];
    r = [];
    g = [];
end

