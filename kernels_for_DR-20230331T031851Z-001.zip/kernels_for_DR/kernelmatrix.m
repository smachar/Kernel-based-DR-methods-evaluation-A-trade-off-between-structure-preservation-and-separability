function K = kernelmatrix(X,ker_type,par,normalized)

if nargin < 3
    par        = 0.1;
    normalized = 1;
end

[N,~] = size(X);

switch ker_type
    case 'gaussian'
        DX = dist(X');
        K  = exp(DX.^2/(2*par^2));
    case 'poly'
        K  = (X*X' + ones(N,N))^round(par);
    case 'linear'
        K  = X*X';
end
     

    K         = 0.5*(K + K');
    kS        = sum(K,1)./N;
    K         = K - bsxfun(@plus, kS, kS') + sum(kS)/N;
        
if normalized
    K         = K./repmat(max(abs(K)),size(K,1),1); 
end